#!/bin/bash
tuscany.sh auth/conup-sample-auth.jar >/dev/null 2>&1 &
tuscany.sh db/conup-sample-db.jar >/dev/null 2>&1 &
tuscany.sh proc/conup-sample-proc.jar >/dev/null 2>&1 &
#tuscany.sh auth/conup-sample-auth.jar &
#tuscany.sh portal/conup-sample-portal.jar 
wait
