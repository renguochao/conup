#!/bin/bash
gnome-terminal -t "auth" -x bash -c "cd /home/artemis;sh startAuth.sh;exec bash;"
gnome-terminal -t "db" -x bash -c "cd /home/artemis;sh startDB.sh;exec bash;"
gnome-terminal -t "proc" -x bash -c "cd /home/artemis;sh startProc.sh;exec bash;"
gnome-terminal -t "portal" -x bash -c "cd /home/artemis;sh startPortal.sh;exec bash;"

#nohup ssh conup@114.212.191.22 "export TUSCANY_HOME=/home/conup/conup-0.9.0-DU;export PATH=/home/conup/conup-0.9.0-DU/bin:$PATH;sh /home/conup/startAuth.sh" #&
#ssh conup@114.212.191.22 "export TUSCANY_HOME=/home/conup/conup-0.9.0-DU;export PATH=/home/conup/conup-0.9.0-DU/bin:$PATH;sh /home/conup/startProc.sh" 
#nohup ./startAuth.sh # &
#nohup ./startProc.sh
#wait
