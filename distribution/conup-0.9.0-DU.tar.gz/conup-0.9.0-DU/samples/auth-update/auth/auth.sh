tuscany.sh /home/artemis/Tuscany/distribution/conup-0.9.0-DU/samples/auth-update/conup-sample-auth.jar
