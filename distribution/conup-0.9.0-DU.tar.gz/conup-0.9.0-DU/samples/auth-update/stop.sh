#!/bin/bash
#ps ax | grep [j]ava | awk '{print $1, $5, $6, $7}'
#ps ax | grep [j]ava | awk '{$1}'

for pid in `ps ax | grep "[j]ava -jar" | awk '{print $1}'`
do
echo "$pid will be killed"
kill $pid
done
