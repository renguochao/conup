#!/bin/bash
tuscany.sh $TUSCANY_HOME/samples/travel-sample/coordination/fullapp-coordination.jar

