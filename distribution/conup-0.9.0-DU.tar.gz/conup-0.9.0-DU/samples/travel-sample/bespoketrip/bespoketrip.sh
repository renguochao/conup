#!/bin/bash
tuscany.sh $TUSCANY_HOME/samples/travel-sample/bespoketrip/fullapp-bespoketrip.jar

