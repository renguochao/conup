#!/bin/bash
tuscany.sh $TUSCANY_HOME/samples/travel-sample/shoppingcart/fullapp-shoppingcart.jar
