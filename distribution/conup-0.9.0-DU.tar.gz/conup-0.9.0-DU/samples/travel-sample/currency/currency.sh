#!/bin/bash
tuscany.sh $TUSCANY_HOME/samples/travel-sample/currency/fullapp-currency.jar

