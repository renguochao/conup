#!/bin/bash
tuscany.sh $TUSCANY_HOME/samples/travel-sample/packagedtrip/fullapp-packagedtrip.jar
