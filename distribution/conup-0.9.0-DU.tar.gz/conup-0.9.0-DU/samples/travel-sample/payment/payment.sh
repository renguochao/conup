#!/bin/bash
tuscany.sh $TUSCANY_HOME/samples/travel-sample/payment/payment-java.jar

