#!/bin/bash
ssh conup@114.212.191.22 "sh /home/conup/conup-0.9.0-DU/samples/stop.sh"
ssh conup@114.212.191.23 "sh /home/conup/conup-0.9.0-DU/samples/stop.sh"
ssh conup@114.212.191.24 "sh /home/conup/conup-0.9.0-DU/samples/stop.sh"

