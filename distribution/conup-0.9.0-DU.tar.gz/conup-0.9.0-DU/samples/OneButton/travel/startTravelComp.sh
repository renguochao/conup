#!/bin/bash
#stop all comps before start
ssh conup@114.212.191.22 "sh /home/conup/conup-0.9.0-DU/samples/stop.sh"
ssh conup@114.212.191.23 "sh /home/conup/conup-0.9.0-DU/samples/stop.sh"
ssh conup@114.212.191.24 "sh /home/conup/conup-0.9.0-DU/samples/stop.sh"

gnome-terminal -t "bespoketrip" -x bash -c "cd ${TUSCANY_HOME}/samples/OneButton/travel;sh bespoketrip.sh;exec bash;"
gnome-terminal -t "currency" -x bash -c "cd ${TUSCANY_HOME}/samples/OneButton/travel;sh currency.sh;exec bash;"
gnome-terminal -t "packagedtrip" -x bash -c "cd ${TUSCANY_HOME}/samples/OneButton/travel;sh packagedtrip.sh;exec bash;"
gnome-terminal -t "shoppingcart" -x bash -c "cd ${TUSCANY_HOME}/samples/OneButton/travel;sh shoppingcart.sh;exec bash;"
gnome-terminal -t "payment" -x bash -c "cd ${TUSCANY_HOME}/samples/OneButton/travel;sh payment.sh;exec bash;"
gnome-terminal -t "coordination" -x bash -c "cd ${TUSCANY_HOME}/samples/OneButton/travel;sh coordination.sh;exec bash;"
