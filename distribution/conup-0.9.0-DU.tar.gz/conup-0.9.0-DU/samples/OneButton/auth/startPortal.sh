#!/bin/bash
ssh conup@114.212.191.22 "export TUSCANY_HOME=/home/conup/conup-0.9.0-DU;export PATH=/home/conup/conup-0.9.0-DU/bin:$PATH;sh /home/conup/startPortal.sh"
