#!/bin/bash
gnome-terminal -t "auth" -x bash -c "cd ${TUSCANY_HOME}/samples/OneButton/auth;sh startAuth.sh;exec bash;"
gnome-terminal -t "db" -x bash -c "cd ${TUSCANY_HOME}/samples/OneButton/auth;sh startDB.sh;exec bash;"
gnome-terminal -t "proc" -x bash -c "cd ${TUSCANY_HOME}/samples/OneButton/auth;sh startProc.sh;exec bash;"
gnome-terminal -t "portal" -x bash -c "cd ${TUSCANY_HOME}/samples/OneButton/auth;sh startPortal.sh;exec bash;"

